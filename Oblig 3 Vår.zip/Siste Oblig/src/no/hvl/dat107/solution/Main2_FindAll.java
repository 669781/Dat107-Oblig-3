package no.hvl.dat107.solution;

import java.util.List;
import java.util.Map;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;

public class Main2_FindAll {

	public static void main(String[] args) {

		String jpql = "SELECT p FROM Person p"; //NB! Dette er ikke SQL, men JPQL
		List<Ansatt> personer = null;
		
		EntityManagerFactory emf = Persistence
				.createEntityManagerFactory("personPersistenceUnit", 
				Map.of("jakarta.persistence.jdbc.password", "pass"));

		System.out.println("Kobler til database...");
		EntityManager em = emf.createEntityManager();
		try {
	        TypedQuery<Ansatt> query = em.createQuery(jpql, Ansatt.class);
	        personer = query.getResultList();
		} finally {
	        em.close();
		}
		
		System.out.println("Resultat:");
		for (Ansatt p : personer) {
			System.out.println(p);
		}
		System.out.println("Ferdig!");
	}
}
