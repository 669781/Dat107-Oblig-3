package no.hvl.dat107.solution;

import java.sql.Connection;
import java.util.Scanner;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Main1 {

	

	public static void main(String[] args) throws ClassNotFoundException {

		 AnsattDAO ansattDAO = new AnsattDAO();
		
		Scanner myObj = new Scanner(System.in);
		
		
		System.out.println("Hva vil du gjøre?");
		System.out.println("1: Søke etter ansatt med ansatt ID");
		System.out.println("2: Søke etter ansatt med brukernavn");
		System.out.println("3: Utlisting av alle ansatte");
		System.out.println("4: Oppdatere en ansatt sin stilling");
		System.out.println("5: Legge inn en ny ansatt");
		
		int velg = myObj.nextInt();
		
		switch(velg) {
		case 1:
			System.out.println("Skriv in ansatt ID du søker");
			int i = myObj.nextInt();
			Ansatt k = ansattDAO.finnAnsattMedId(i);
			System.out.println(k);
			break;
		}

	}

	
}
