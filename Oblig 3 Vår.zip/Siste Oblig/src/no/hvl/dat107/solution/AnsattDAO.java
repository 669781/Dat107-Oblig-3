package no.hvl.dat107.solution;

import java.sql.Date;
import java.util.List;
import java.util.Map;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;


public class AnsattDAO {

    private EntityManagerFactory emf;

    public AnsattDAO() {
        emf = Persistence.createEntityManagerFactory("AnsattPersistenceUnit",
        		Map.of("jakarta.persistence.jdbc.password", "pass"));
    }
    
    public Ansatt finnAnsattMedId(int id) {

        EntityManager em = emf.createEntityManager();

        Ansatt ansatt = null;
        try {
            ansatt = em.find(Ansatt.class, id);
        } finally {
            em.close();
        }
        return ansatt;
    }

	public Ansatt finnAnsattMedBrukernavn(String navn) {
		EntityManager em = emf.createEntityManager();
		
		Ansatt ansatt = null;
		try {
			ansatt = em.find(Ansatt.class, navn);
		
		} finally {
			em.close();
		}
		
		return ansatt;
		
	}
	public List<Ansatt> hentAlleAnsatte () {
		
		  EntityManager em = emf.createEntityManager();

	        List<Ansatt> p = null;
	        try {
	            TypedQuery<Ansatt> query 
	                    = em.createQuery("SELECT * FROM Ansatt", Ansatt.class);
	            p = query.getResultList();
	            
	        } finally {
	            em.close();
	        }
	        return p;	}

	public Ansatt opddaterStilligLonn(String stilling, int lonn) {
		  EntityManager em = emf.createEntityManager();
		  
		  Ansatt p = null;
		  try {
			  TypedQuery<Ansatt> query
			  			= em.createQuery("UPDATE Ansatt SET stilling = " + stilling + ", SET manedlonn = " +  lonn, Ansatt.class);
		  } finally {
			  em.close();
		  }
		  
		return p;
	}
	public Ansatt findAnsattByName(String name) {
        EntityManager em = emf.createEntityManager();
        TypedQuery<Ansatt> query = em.createQuery("SELECT p FROM Person p WHERE p.name = :name", Ansatt.class);
        query.setParameter("name", name);
        Ansatt person = null;
        try {
            person = query.getSingleResult();
        } catch (Exception e) {
            // handle exception if no result found
        }
        em.close();
        return person;
    }
	public void updateAnsattStillingOgLonn(int ansattId, String stilling, int manedslonn) {
	    EntityManager em = emf.createEntityManager();
	    EntityTransaction tx = null;
	    try {
	        tx = em.getTransaction();
	        tx.begin();
	        Ansatt ansatt = em.find(Ansatt.class, ansattId);
	        if (ansatt != null) {
	            ansatt.setStilling(stilling);
	            ansatt.setMndLønn(manedslonn);
	            em.persist(ansatt);
	            tx.commit();
	        }
	    } catch (Exception e) {
	        if (tx != null) {
	            tx.rollback();
	        }
	        e.printStackTrace();
	    } finally {
	        em.close();
	    }
	}
	public void addAnsatt(int ansatt_id, String brukernavn, String fornavn, String etternavn, Date ansettelsesdato, String stilling, int manedslonn) {
	    EntityManagerFactory emf = Persistence.createEntityManagerFactory("ansattPersistenceUnit");
	    EntityManager em = emf.createEntityManager();

	    Ansatt ansatt = new Ansatt();
	    ansatt.setAnsattNr(ansatt_id);
	    ansatt.setBrukernavn(brukernavn);
	    ansatt.setFornavn(fornavn);
	    ansatt.setEtternavn(etternavn);
	    ansatt.setAnsattDato(ansettelsesdato);
	    ansatt.setStilling(stilling);
	    ansatt.setMndLønn(manedslonn);

	    EntityTransaction tx = em.getTransaction();
	    try {
	        tx.begin();
	        em.persist(ansatt);
	        tx.commit();
	    } catch (RuntimeException e) {
	        tx.rollback();
	        throw e;
	    } finally {
	        em.close();
	    }
	}


	}
