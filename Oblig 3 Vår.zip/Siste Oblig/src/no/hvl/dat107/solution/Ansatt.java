package no.hvl.dat107.solution;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(schema = "public")
//@NamedQuery(name = "hentAllePersoner", query ="SELECT p FROM Person as p order by p.id")
public class Ansatt {
	
	@Id
	@Column(name = "ansatt_id")
	private int ansattNr;

	
	private String brukernavn;
	
	private String fornavn;
	private String etternavn;
	@Column(name = "ansettelsesdato")
	private Date ansattDato;
	private String stilling;
	@Column(name = "manedslonn")
	private long mndLonn;
	
	public Ansatt (){
		
		
	}
	
	public Ansatt (int nr, String brukernavn, String fornavn, String etternavn, Date ansattDato, String stilling, long lønn){
		ansattNr = nr;
		this.brukernavn = brukernavn;
		this.fornavn = fornavn;
		this.ansattDato = ansattDato;
		this.stilling = stilling;
		mndLonn = lønn;
		
	}
	
	public String toString() {
		return "Ansatt [ansattNr=" + ansattNr + ", brukernavn=" + brukernavn + ", fornavn=" + fornavn
				+ ", etternavn=" + etternavn + ", ansattDato=" + ansattDato + ", stilling=" + stilling
				+ ", mndLønn=" + mndLonn + "]";
	}
	public int getAnsattNr() {
		return ansattNr;
	}
	public void setAnsattNr(int ansattNr) {
		this.ansattNr = ansattNr;
	}
	public String getBrukernavn() {
		return brukernavn;
	}
	public void setBrukernavn(String brukernavn) {
		this.brukernavn = brukernavn;
	}
	public String getFornavn() {
		return fornavn;
	}
	public void setFornavn(String fornavn) {
		this.fornavn = fornavn;
	}
	public String getEtternavn() {
		return etternavn;
	}
	public void setEtternavn(String etternavn) {
		this.etternavn = etternavn;
	}
	public Date getAnsattDato() {
		return ansattDato;
	}
	public void setAnsattDato(Date ansattDato) {
		this.ansattDato = ansattDato;
	}
	public String getStilling() {
		return stilling;
	}
	public void setStilling(String stilling) {
		this.stilling = stilling;
	}
	public long getMndLønn() {
		return mndLonn;
	}
	public void setMndLønn(long mndLønn) {
		this.mndLonn = mndLønn;
	}
}
